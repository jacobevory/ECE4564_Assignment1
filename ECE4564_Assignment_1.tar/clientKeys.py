#keys to access twitter

ckey = '81bWC84J6xGLmjDyPdrChhz02'
csec = 'crs5WnkfMokqo5vjG7ceWuAqIqEuzgBBxCzTKczNmtEdCGcI5Y'
atok = '913827757070733312-qHrxDoaavKU8s9Ww2L2PG6XTE9JDvYg'
asec = 'JM1HOhEpvvz5In4UtXa7HxumMfFc348q6wZJzPFwS3Jp0'

track = ['#ECE4564T26']
hashstr = '#ECE4564T26'
