# ECE4564_Assignment1

Raspberry Pi needs to run

$sudo pip3 install gTTS

$sudo pip3 install wolframalpha

$sudo pip3 install tweepy

$sudo apt-get install mpg123

#TODO:
  filter incoming twiter stream
