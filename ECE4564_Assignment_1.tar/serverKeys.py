#appid for WolframAplha

wolfappid = 'P9WYYV-EH3LA7A65X'
